# sample-auth-redirect
Trivial AngularJS app to demonstrate redirection logic for protected resources.

Starting boilerplate code borrowed from [this blog](http://mherman.org/blog/2015/07/02/handling-user-authentication-with-the-mean-stack/)

## running the app ![alt text](http://www.bedug.com/pics/smiley/MegaMan-Running.gif)

1. ```npm install```
1. ```npm run bower```
1. ```npm start```
1. Hit the app at http://localhost:3000/